package Tema;

public enum StareCrocodil {
	Normal,
	Flamand
}
