package Tema;

public interface IStare {
	public abstract void print(String text);
}
