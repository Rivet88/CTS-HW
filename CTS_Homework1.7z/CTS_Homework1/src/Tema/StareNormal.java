package Tema;

public class StareNormal implements IStare {

	public void print(String text) {
		System.out.println("In mod normal: "+text);
		
	}

}
