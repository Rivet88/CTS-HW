package Tema;

public class RatonSimplu extends AbstractRaton{

	
	private String nume;

	public RatonSimplu(String name){
		this.nume=name;
	}
	
	
	public String getNume() {
		return "nume raton simplu";
}
}
