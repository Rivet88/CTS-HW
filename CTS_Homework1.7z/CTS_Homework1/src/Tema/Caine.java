package Tema;

public class Caine implements Animal {
	
	String Carnivor="false";
	@Override
	public void makeSound() {
		System.out.print("HAM-HAM! ");
		
	}

	
}
