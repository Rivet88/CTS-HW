package Tema;

public abstract class AbstractRaton {
	String nume;
	
	public abstract String getNume();
}


