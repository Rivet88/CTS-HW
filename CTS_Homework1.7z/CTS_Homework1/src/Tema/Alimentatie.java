package Tema;

public enum Alimentatie {
	CARNE,
	LAPTE,
	LEGUME,
	OASE,
	
}
