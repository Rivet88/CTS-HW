package Tema;

public interface Animal {
		void makeSound();
		
}
