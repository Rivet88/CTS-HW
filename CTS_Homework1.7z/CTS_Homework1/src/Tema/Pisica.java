package Tema;

public class Pisica implements Animal {
	
	String Carnivor="false";
	@Override
	public void makeSound() {
		System.out.print("Miau ");
	}

}
